-- schema.sql for Hotel Management System

-- USERS
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('clerk', 'manager', 'admin') NOT NULL
);

-- GUESTS
CREATE TABLE guests (
  guest_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  phone VARCHAR(20),
  is_vip BOOLEAN DEFAULT FALSE
);

-- ROOMS
CREATE TABLE rooms (
  room_id INT AUTO_INCREMENT PRIMARY KEY,
  room_number VARCHAR(10) UNIQUE,
  room_type VARCHAR(50),
  rate DECIMAL(10,2),
  status ENUM('available', 'reserved', 'occupied', 'maintenance') DEFAULT 'available'
);

-- RESERVATIONS
CREATE TABLE reservations (
  reservation_id INT AUTO_INCREMENT PRIMARY KEY,
  guest_id INT,
  room_id INT,
  checkin_date DATE,
  checkout_date DATE,
  reservation_time DATETIME,
  credit_card_number VARCHAR(20),
  is_walkin BOOLEAN DEFAULT FALSE,
  status ENUM('reserved', 'checked_in', 'checked_out', 'cancelled', 'no_show', 'late_checkout') DEFAULT 'reserved',
  FOREIGN KEY (guest_id) REFERENCES guests(guest_id),
  FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

-- SERVICES
CREATE TABLE services (
  service_id INT AUTO_INCREMENT PRIMARY KEY,
  reservation_id INT,
  service_name VARCHAR(100),
  cost DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reservation_id) REFERENCES reservations(reservation_id)
);

-- ACTION LOGS
CREATE TABLE action_logs (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  action_type VARCHAR(50),
  message TEXT,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id)

);

CREATE TABLE action_logs (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  action_type VARCHAR(50),
  description TEXT,
  timestamp DATETIME
);

