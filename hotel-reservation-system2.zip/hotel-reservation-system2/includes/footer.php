</div> <!-- Close container from header -->

<footer class="text-center mt-5 py-4 border-top">
  <p class="mb-0 text-muted">© <?php echo date("Y"); ?> Hotel Prime. All rights reserved.</p>
</footer>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- FontAwesome (optional icons interactivity) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>

<!-- Optional custom JS -->
<script src="/assets/js/scripts.js"></script>

</body>
</html>
