<?php
// Start session and check authentication
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'clerk') {
    header("Location: login.php");
    exit();
}

// Database connection
require_once 'db.php';

// Get today's date for default filter
$today = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luxora Hotel Suite - Clerk Dashboard</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2980b9;
            --accent-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .sidebar {
            background-color: var(--dark-color);
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }
        
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 5px;
            border-radius: 5px;
            padding: 10px 15px;
        }
        
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .badge-success {
            background-color: #2ecc71;
        }
        
        .badge-warning {
            background-color: #f39c12;
        }
        
        .badge-danger {
            background-color: #e74c3c;
        }
        
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table th {
            background-color: var(--light-color);
            font-weight: 600;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .search-box {
            position: relative;
        }
        
        .search-box i {
            position: absolute;
            top: 10px;
            left: 10px;
            color: #7f8c8d;
        }
        
        .search-box input {
            padding-left: 35px;
            border-radius: 20px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }
        
        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .user-profile .user-info {
            line-height: 1.2;
        }
        
        .user-profile .user-name {
            font-weight: 600;
            font-size: 14px;
        }
        
        .user-profile .user-role {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.7);
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            font-size: 10px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .status-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 5px;
        }
        
        .status-available {
            background-color: #2ecc71;
        }
        
        .status-occupied {
            background-color: #e74c3c;
        }
        
        .status-reserved {
            background-color: #f39c12;
        }
        
        .status-maintenance {
            background-color: #7f8c8d;
        }
        
        /* Responsive adjustments */
        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
                overflow: hidden;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .user-profile {
                justify-content: center;
            }
            
            .user-profile .user-info {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['user_name']) ?>&background=3498db&color=fff" alt="User">
                    <div class="user-info">
                        <div class="user-name"><?= htmlspecialchars($_SESSION['user_name']) ?></div>
                        <div class="user-role">Clerk</div>
                    </div>
                </div>
                
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reservations.php">
                            <i class="fas fa-calendar-check"></i>
                            <span>Reservations</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="checkin.php">
                            <i class="fas fa-sign-in-alt"></i>
                            <span>Check-In</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="checkout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Check-Out</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="billing.php">
                            <i class="fas fa-receipt"></i>
                            <span>Billing</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed"></i>
                            <span>Room Management</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative" href="notifications.php">
                            <i class="fas fa-bell"></i>
                            <span>Notifications</span>
                            <span class="notification-badge">3</span>
                        </a>
                    </li>
                    <li class="nav-item mt-4">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Clerk Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                            <i class="fas fa-calendar-alt"></i> <?= date('F j, Y') ?>
                        </button>
                    </div>
                </div>
                
                <!-- Summary Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted mb-2">Today's Check-Ins</h6>
                                        <h3 class="mb-0">
                                            <?php
                                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM reservations 
                                                WHERE checkin_date = ? AND status = 'Checked-In'");
                                            $stmt->execute([$today]);
                                            echo $stmt->fetchColumn();
                                            ?>
                                        </h3>
                                    </div>
                                    <div class="bg-primary bg-opacity-10 p-3 rounded">
                                        <i class="fas fa-sign-in-alt text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted mb-2">Today's Check-Outs</h6>
                                        <h3 class="mb-0">
                                            <?php
                                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM reservations 
                                                WHERE checkout_date = ? AND status = 'Checked-Out'");
                                            $stmt->execute([$today]);
                                            echo $stmt->fetchColumn();
                                            ?>
                                        </h3>
                                    </div>
                                    <div class="bg-success bg-opacity-10 p-3 rounded">
                                        <i class="fas fa-sign-out-alt text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted mb-2">Available Rooms</h6>
                                        <h3 class="mb-0">
                                            <?php
                                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM rooms WHERE status = 'Available'");
                                            $stmt->execute();
                                            echo $stmt->fetchColumn();
                                            ?>
                                        </h3>
                                    </div>
                                    <div class="bg-info bg-opacity-10 p-3 rounded">
                                        <i class="fas fa-bed text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted mb-2">Pending Reservations</h6>
                                        <h3 class="mb-0">
                                            <?php
                                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM reservations 
                                                WHERE status = 'Pending'");
                                            $stmt->execute();
                                            echo $stmt->fetchColumn();
                                            ?>
                                        </h3>
                                    </div>
                                    <div class="bg-warning bg-opacity-10 p-3 rounded">
                                        <i class="fas fa-clock text-warning"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Today's Arrivals and Departures -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-user-clock me-2"></i> Today's Arrivals
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Guest</th>
                                                <th>Room</th>
                                                <th>Time</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $stmt = $pdo->prepare("SELECT r.reservation_id, g.first_name, g.last_name, 
                                                rm.room_number, rm.room_type, r.checkin_date, r.status 
                                                FROM reservations r
                                                JOIN guests g ON r.guest_id = g.guest_id
                                                JOIN rooms rm ON r.room_id = rm.room_id
                                                WHERE r.checkin_date = ?
                                                ORDER BY r.checkin_date");
                                            $stmt->execute([$today]);
                                            $arrivals = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            
                                            foreach ($arrivals as $arrival) {
                                                $status_class = '';
                                                if ($arrival['status'] == 'Checked-In') {
                                                    $status_class = 'badge-success';
                                                } elseif ($arrival['status'] == 'Pending') {
                                                    $status_class = 'badge-warning';
                                                } elseif ($arrival['status'] == 'No-Show') {
                                                    $status_class = 'badge-danger';
                                                }
                                                
                                                echo '<tr>';
                                                echo '<td>' . htmlspecialchars($arrival['first_name'] . ' ' . $arrival['last_name']) . '</td>';
                                                echo '<td>' . htmlspecialchars($arrival['room_number'] . ' (' . $arrival['room_type'] . ')') . '</td>';
                                                echo '<td>' . date('h:i A', strtotime($arrival['checkin_date'])) . '</td>';
                                                echo '<td><span class="badge ' . $status_class . '">' . $arrival['status'] . '</span></td>';
                                                echo '</tr>';
                                            }
                                            
                                            if (empty($arrivals)) {
                                                echo '<tr><td colspan="4" class="text-center">No arrivals scheduled for today</td></tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-user-check me-2"></i> Today's Departures
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Guest</th>
                                                <th>Room</th>
                                                <th>Time</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $stmt = $pdo->prepare("SELECT r.reservation_id, g.first_name, g.last_name, 
                                                rm.room_number, rm.room_type, r.checkout_date, r.status 
                                                FROM reservations r
                                                JOIN guests g ON r.guest_id = g.guest_id
                                                JOIN rooms rm ON r.room_id = rm.room_id
                                                WHERE r.checkout_date = ?
                                                ORDER BY r.checkout_date");
                                            $stmt->execute([$today]);
                                            $departures = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            
                                            foreach ($departures as $departure) {
                                                $status_class = '';
                                                if ($departure['status'] == 'Checked-Out') {
                                                    $status_class = 'badge-success';
                                                } elseif ($departure['status'] == 'Checked-In') {
                                                    $status_class = 'badge-warning';
                                                } elseif ($departure['status'] == 'No-Show') {
                                                    $status_class = 'badge-danger';
                                                }
                                                
                                                echo '<tr>';
                                                echo '<td>' . htmlspecialchars($departure['first_name'] . ' ' . $departure['last_name']) . '</td>';
                                                echo '<td>' . htmlspecialchars($departure['room_number'] . ' (' . $departure['room_type'] . ')') . '</td>';
                                                echo '<td>' . date('h:i A', strtotime($departure['checkout_date'])) . '</td>';
                                                echo '<td><span class="badge ' . $status_class . '">' . $departure['status'] . '</span></td>';
                                                echo '</tr>';
                                            }
                                            
                                            if (empty($departures)) {
                                                echo '<tr><td colspan="4" class="text-center">No departures scheduled for today</td></tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-bolt me-2"></i> Quick Actions
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <a href="new_reservation.php" class="btn btn-primary w-100">
                                            <i class="fas fa-plus me-2"></i> New Reservation
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="checkin.php" class="btn btn-success w-100">
                                            <i class="fas fa-sign-in-alt me-2"></i> Check-In Guest
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="checkout.php" class="btn btn-warning w-100">
                                            <i class="fas fa-sign-out-alt me-2"></i> Check-Out Guest
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="billing.php" class="btn btn-info w-100">
                                            <i class="fas fa-file-invoice-dollar me-2"></i> Create Bill
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Room Status Overview -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-bed me-2"></i> Room Status Overview
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Room No.</th>
                                                <th>Type</th>
                                                <th>Status</th>
                                                <th>Guest</th>
                                                <th>Check-Out</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $stmt = $pdo->query("SELECT r.room_id, r.room_number, r.room_type, r.status, 
                                                g.first_name, g.last_name, res.checkout_date
                                                FROM rooms r
                                                LEFT JOIN reservations res ON r.room_id = res.room_id AND res.status = 'Checked-In'
                                                LEFT JOIN guests g ON res.guest_id = g.guest_id
                                                ORDER BY r.room_number");
                                            $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            
                                            foreach ($rooms as $room) {
                                                $status_class = '';
                                                if ($room['status'] == 'Available') {
                                                    $status_class = 'status-available';
                                                } elseif ($room['status'] == 'Occupied') {
                                                    $status_class = 'status-occupied';
                                                } elseif ($room['status'] == 'Reserved') {
                                                    $status_class = 'status-reserved';
                                                } elseif ($room['status'] == 'Maintenance') {
                                                    $status_class = 'status-maintenance';
                                                }
                                                
                                                echo '<tr>';
                                                echo '<td>' . htmlspecialchars($room['room_number']) . '</td>';
                                                echo '<td>' . htmlspecialchars($room['room_type']) . '</td>';
                                                echo '<td><span class="status-indicator ' . $status_class . '"></span>' . $room['status'] . '</td>';
                                                
                                                if ($room['status'] == 'Occupied' || $room['status'] == 'Reserved') {
                                                    echo '<td>' . htmlspecialchars($room['first_name'] . ' ' . $room['last_name']) . '</td>';
                                                    echo '<td>' . ($room['checkout_date'] ? date('M j, Y', strtotime($room['checkout_date'])) : 'N/A') . '</td>';
                                                } else {
                                                    echo '<td>-</td>';
                                                    echo '<td>-</td>';
                                                }
                                                
                                                echo '<td>';
                                                if ($room['status'] == 'Occupied') {
                                                    echo '<a href="checkout.php?room_id=' . $room['room_id'] . '" class="btn btn-sm btn-outline-warning me-1">Check-Out</a>';
                                                } elseif ($room['status'] == 'Available') {
                                                    echo '<a href="checkin.php?room_id=' . $room['room_id'] . '" class="btn btn-sm btn-outline-success me-1">Check-In</a>';
                                                }
                                                echo '<a href="room_details.php?id=' . $room['room_id'] . '" class="btn btn-sm btn-outline-info">Details</a>';
                                                echo '</td>';
                                                echo '</tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JavaScript -->
    <script>
        // Toggle sidebar on small screens
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggle = document.body.querySelector('#sidebarToggle');
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', event => {
                    event.preventDefault();
                    document.body.classList.toggle('sb-sidenav-toggled');
                    localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
                });
            }
            
            // Highlight active nav link
            const currentPage = window.location.pathname.split('/').pop();
            const navLinks = document.querySelectorAll('.nav-link');
            
            navLinks.forEach(link => {
                if (link.getAttribute('href') === currentPage) {
                    link.classList.add('active');
                }
            });
            
            // Auto-refresh dashboard every 5 minutes
            setTimeout(function() {
                window.location.reload();
            }, 300000); // 5 minutes
        });
        
        // Search functionality
        function searchReservations() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('reservationsTable');
            const tr = table.getElementsByTagName('tr');
            
            for (let i = 0; i < tr.length; i++) {
                const td = tr[i].getElementsByTagName('td')[0]; // Search by guest name
                if (td) {
                    const txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = '';
                    } else {
                        tr[i].style.display = 'none';
                    }
                }
            }
        }
    </script>
</body>
</html>